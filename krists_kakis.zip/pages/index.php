<?php
$page->set_page_title('Home');
?>
<div class="card">
	<div class="card-body">
		<form method="get" action="/feed/">
			<div class="mb-3">
				<label class="form-label">Barotāja vārds</label>
				<input type="text" class="form-control" name="vards" autocomplete="name" placeholder="Sāciet rakstīt..." required />
			</div>
			<button type="submit" class="btn btn-primary">Autorizēties</button>
		</form>
	</div>
</div>