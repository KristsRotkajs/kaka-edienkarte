CREATE TABLE `barosana` (
  `id` int UNSIGNED NOT NULL,
  `cilveks_vards` varchar(255) NOT NULL,
  `datums` int UNSIGNED NOT NULL,
  `piezimes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `barosana` (`id`, `cilveks_vards`, `datums`, `piezimes`) VALUES
(1, 'Krists', 1716578700, 'par labu uzvedību');

ALTER TABLE `barosana`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `barosana`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;