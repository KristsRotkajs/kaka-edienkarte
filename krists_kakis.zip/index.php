<?php
require 'init.php';