<?php
function split_to_segments($url){
	$return = explode("/", $url);
	array_shift($return);
	if(substr($url, -1) == "/"){
		array_pop($return);
	}
	
	for($i=count($return)+1; $i<=4; $i++){
		$return[$i-1] = false;
	}
	
	return $return;
}

function segments_to_get($segments){
	$_GET['act'] = $segments[0];
	$_GET['subact'] = $segments[1];
	$_GET['id'] = $segments[2];
	$_GET['subid'] = $segments[3];
	$page = (int)array_search('page', $segments);
	
	if($page == 1){
		unset($_GET['id']);
	}
	
	if(count($segments) > 4){
		array_shift($segments);
		array_shift($segments);
		array_shift($segments);
		array_shift($segments);
		$_GET['other'] = implode("/", $segments);
	}
}

function get_post($index, $secure = false){
	if(isset($_POST[$index])){
		if($secure){
			return htmlspecialchars(urldecode($_POST[$index]));
		}else{
			return ($_POST[$index]);
		}
	}else{
		return false;
	}
}

function get_get($index, $secure = false){
	if(isset($_GET[$index])){
		if($secure){
			return htmlspecialchars(urldecode($_GET[$index]));
		}else{
			return urldecode($_GET[$index]);
		}
	}else{
		return false;
	}
}

function get_segment($segment, $next = 1){
	global $segments;
	$sn = false;
	$segment_nr = array_search($segment, $segments);
	
	if($segment_nr && isset($segments[$segment_nr + $next]))
		$sn = $segments[$segment_nr + $next];
	
	return $sn;
}

function format_time($time){
	$today = strtotime('Today');
	$yesterday = strtotime('Yesterday');
	$current_year = strtotime(date('Y') . '-01-01');
	$months_en = array(
                       'January',
                       'February',
                       'March',
                       'April',
                       'May',
                       'June',
                       'July',
                       'August',
                       'September',
                       'October',
                       'November',
                       'December');
	$months_lv = array(
                       'Janvārī',
                       'Februārī',
                       'Martā',
                       'Aprīlī',
                       'Maijā',
                       'Jūnijā',
                       'Jūlijā',
                       'Augustā',
                       'Septembrī',
                       'Oktobrī',
                       'Novembrī',
                       'Decembrī');

	if($time >= $today){
		$time = time() - $time;
		$return = $time;
		
		if($time <= 5){
			$return = 'tikko';
		}elseif($time <= 59){
			$return = 'pirms ' . $time . (substr($time, -1) == 1 && $time != 11  ? ' sekundes':' sekundēm');
		}elseif($time <= 60*60-1){
			$time = floor($time/60);
			$return = 'pirms ' . $time .  (substr($time, -1) == 1 && $time != 11  ? ' minūtes':' minūtēm');
		}else{
			$time = floor($time/3600);
			$return = 'pirms ' . $time .  (substr($time, -1) == 1 && $time != 11 ? ' stundas':' stundām');
		}
	}elseif($time < $today and $time >= $yesterday){
		$return = 'Vakar, ' . date('H:i', $time);
	}elseif($time < $current_year){
		$time = date("Y. \g\a\d\a d. F, H:i", $time);
		$return =  mb_strtolower(str_ireplace($months_en, $months_lv, $time), 'UTF8');
	}else{
		$time = date("j. F, H:i", $time);
		$return =  mb_strtolower(str_ireplace($months_en, $months_lv, $time), 'UTF8');
	}
	
	return $return;
}